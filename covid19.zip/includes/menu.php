<!-- Navigation -->
<nav class="navbar navbar-default navbar-dark fixed-top bg-estate" style="top: -6px;">
  <div class="container">
    <div class="col-sm-10">&nbsp;</div>
    <div class="col-sm-2 icons-menu-top ">
      <a href="#">&nbsp;</a>&nbsp;&nbsp;
    </div>
  </div>
</nav>
<nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-estate fixed-top">
  <div class="container">
    <a class="navbar-brand" href="./"><img src="./img/covid19.png" alt="covid-19>"></a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">&nbsp;</li>
      </ul>
    </div>
  </div>
</nav>