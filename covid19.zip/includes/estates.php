<!-- Portfolio Section -->
<h2>Material Informativo para Descargar</h2>

<div class="row">
  <div class="col-lg-6 col-sm-12 portfolio-item">
    <div class="card h-100">
      <a href="#"><img class="card-img-top" src="./img/estates/ciudadano.jpg" alt=""></a>
      <div class="card-body">
        <h4 class="card-title">
          <a href="#">Listado PDF</a>
        </h4>
        <table class="table table-striped">
          <tbody>
            <tr>
              <th scope="row" class="icon_color"><i class="fa fa-file" aria-hidden="true"></i></th>
              <td><a href="./instructivo_para_personas_aisladas.pdf">Instructivos para personas aisladas</a></td>
            </tr>
            <tr>
              <th scope="row" class="icon_color"><i class="fa fa-file" aria-hidden="true"></i></th>
              <td><a href="./instructivo_para_personas_aisladas_sin_sintomas.pdf">Instructivos para personas aisladas sin síntomas</a></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <div class="col-lg-6 col-sm-12 portfolio-item">
    <div class="card h-100">
      <a href="#"><img class="card-img-top" src="./img/estates/equiposalud.jpg" alt=""></a>
      <div class="card-body">
        <h4 class="card-title">
          <a href="#">Listado PDF</a>
        </h4>
        <table class="table table-striped">
          <tbody>
            <tr>
              <th scope="row" class="icon_color"><i class="fa fa-file" aria-hidden="true"></i></th>
              <td><a href="./pdf/protocolo_provincial_de_COVID-19.pdf">Protocolo Provincial COVID-19</a></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<!-- /.row -->